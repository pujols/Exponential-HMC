function [qHistory_expHMC, TIME_spent, acc_rate] = expHMC_fastBLR(mu, sigmaInverse, m_gradLogP, m_logP, M, h, L, num_burn, num_sample, q_initial, X, Y, sigma_prior)
% function [qHistory_expHMC, TIME_spent, acc_rate] = expHMC_fastBLR_full(mu, sigmaInverse, m_gradLogP, m_logP, M, h, L, num_burn, num_sample, q_initial, X, Y, sigma_prior)
% rng('shuffle');
%% Parameters
% Exponential parameters: mu, sigmaInverse 
% HMC parameters: m(inus)_gradLogP, m(inus)_logP, M, h(step size), L(#steps) 
% MCMC parameters: num_burn, num_sample

%% Presetting
sqrt_M = M^(0.5);
inv_sqrt_M = inv(sqrt_M);
inv_M = inv(M);
sqrt_sigmaInverse = sigmaInverse^(0.5);

% [N, D] = size(X);
%% Initialization
d = length(mu);
if (q_initial(1) == 10^10)
    q = randn(d, 1); q = sqrt_sigmaInverse\q + mu;
else
    q = q_initial;
end

% transformation
% =============== Speed Up ======================================
XY = X'*Y;
Xmu = X*mu;
sqrt_Mmu = inv_sqrt_M*mu;
sqrt_MXY = inv_sqrt_M*XY;
sqrt_MsigmaInversesqrt_M = inv_sqrt_M*sigmaInverse*inv_sqrt_M;
sqrt_Mmusigma_prior = sqrt_Mmu/sigma_prior;
sqrt_MX = inv_sqrt_M*(X');
fastALL = sqrt_Mmusigma_prior - sqrt_MXY;
% ===============================================================
% structure = precompute_fastBLR_accurate(mu, sigmaInverse, h, inv_sqrt_M);
structure = precompute_fastBLR(mu, sigmaInverse, h, inv_sqrt_M);
% Precomputing
% =============== Speed Up ======================================
SUP1 = inv_M*structure.sinc/sigma_prior;
SUP2 = X*inv_sqrt_M*structure.sinc;
SUP3 = sqrt_MsigmaInversesqrt_M*structure.sinc;
SUP4 = SUP1 - SUP3;
% ===============================================================

original_m_logP = m_logP(q);
qt = q - mu;
r0 = sqrt_M*qt;
% sr0 = structure.sinc*r0;
F0 = fastALL + sqrt_MX*(1./(1+exp(-(SUP2*r0)-Xmu))) + SUP4*r0;

%% Burning
qHistory_expHMC_burn = zeros(d, num_burn);

for n = 1:num_burn
    
% Random p
    z0 = randn(d, 1);
    origEnergy = original_m_logP + 0.5*(z0'*z0);
    
% Run L times
    F_start = F0;
    r_start = r0;
    RandomStep = ceil(rand*L);
    for m = 1:RandomStep
% =============== Speed Up ======================================
%         [z11, r11, F11] = exponentialStep_fastBLR(z0, r0, structure, F0, X, M, sqrt_M, sigma_prior, Xmu, sqrt_MsigmaInversesqrt_M, sqrt_MX, fastALL);
        r11 = structure.cosine*r0 + structure.fast1*z0 - structure.fast2*F0;
        % sr = structure.sinc*r11;
        F11 = fastALL + sqrt_MX*(1./(1+exp(-(SUP2*r11)-Xmu))) + SUP4*r11;
        z11 = -structure.fast3*r0 + structure.cosine*z0 - (structure.fast4*F0 + structure.fast5*F11); 
% ===============================================================
        if(isnan(sum(r11)) || isnan(sum(z11)) || isinf(sum(r11)) || isinf(sum(z11)))
            break;
        end
        z0 = real(z11); r0 = real(r11); F0 = real(F11);
    end
    
% Acceptance-rejection
    proposed_z = z0;
    proposed_r = r0;

% =============== Speed Up ======================================
    proposedQ = inv_sqrt_M*proposed_r + mu;
    new_m_logP = 0.5*(proposedQ'*proposedQ)/sigma_prior - (proposedQ'*XY - sum(log(1+exp(X*proposedQ))));
% ===============================================================
    newEnergy = new_m_logP + 0.5*(proposed_z'*proposed_z);
    acceptRatio = min(exp(origEnergy-newEnergy), 1);
    
    if rand(1,1) <= acceptRatio
        r0 = proposed_r;
        original_m_logP = new_m_logP;
    else
        F0 = F_start;
        r0 = r_start;
    end
    q = inv_sqrt_M*r0 + mu;
    qHistory_expHMC_burn(:, n) = q;
end

%% #################### Left Blank for code checking ##################







































%% #################### Left Blank for code checking ##################
%% Sampling
% m_gradLogP = @(q) q/sigma_prior + X'*(1./(1+exp(-X*q)) - Y);
% m_logP = @(q) 0.5*q'*q/sigma_prior - (q'*X'*Y - sum(log(1+exp(X*q))));
% nonlinearPart = @(q) m_gradLogP(q) - InverseSigma_posterior*(q-Mu);

accept_count = 0;
qHistory_expHMC = zeros(d, num_sample);

% transformation
% =============== Speed Up ======================================
XY = X'*Y;
Xmu = X*mu;
sqrt_Mmu = inv_sqrt_M*mu;
sqrt_MXY = inv_sqrt_M*XY;
sqrt_MsigmaInversesqrt_M = inv_sqrt_M*sigmaInverse*inv_sqrt_M;
sqrt_Mmusigma_prior = sqrt_Mmu/sigma_prior;
sqrt_MX = inv_sqrt_M*(X');
fastALL = sqrt_Mmusigma_prior - sqrt_MXY;
% ===============================================================

tic;
structure = precompute_fastBLR(mu, sigmaInverse, h, inv_sqrt_M);

% Precomputing
% =============== Speed Up ======================================
SUP1 = inv_M*structure.sinc/sigma_prior;
SUP2 = X*inv_sqrt_M*structure.sinc;
SUP3 = sqrt_MsigmaInversesqrt_M*structure.sinc;
SUP4 = SUP1 - SUP3;
% ===============================================================

original_m_logP = m_logP(q);
qt = q - mu;
r0 = sqrt_M*qt;
% sr0 = structure.sinc*r0;
F0 = fastALL + sqrt_MX*(1./(1+exp(-(SUP2*r0)-Xmu))) + SUP4*r0;

for n = 1:num_sample
    
% Random p
    z0 = randn(d, 1);
    origEnergy = original_m_logP + 0.5*(z0'*z0);
    
% Run L times
    F_start = F0;
    r_start = r0;
    RandomStep = ceil(rand*L);
    for m = 1:RandomStep
% =============== Speed Up ======================================
%         [z11, r11, F11] = exponentialStep_fastBLR(z0, r0, structure, F0, X, M, sqrt_M, sigma_prior, Xmu, sqrt_MsigmaInversesqrt_M, sqrt_MX, fastALL);
        r11 = structure.cosine*r0 + structure.fast1*z0 - structure.fast2*F0;
        % sr = structure.sinc*r11;
        F11 = fastALL + sqrt_MX*(1./(1+exp(-(SUP2*r11)-Xmu))) + SUP4*r11;
        z11 = -structure.fast3*r0 + structure.cosine*z0 - (structure.fast4*F0 + structure.fast5*F11); 
% ===============================================================
        if(isnan(sum(r11)) || isnan(sum(z11)) || isinf(sum(r11)) || isinf(sum(z11)))
            break;
        end
        z0 = real(z11); r0 = real(r11); F0 = real(F11);
    end
    
% Acceptance-rejection
    proposed_z = z0;
    proposed_r = r0;

% =============== Speed Up ======================================
    proposedQ = inv_sqrt_M*proposed_r + mu;
    new_m_logP = 0.5*(proposedQ'*proposedQ)/sigma_prior - (proposedQ'*XY - sum(log(1+exp(X*proposedQ))));
% ===============================================================
    newEnergy = new_m_logP + 0.5*(proposed_z'*proposed_z);
    acceptRatio = min(exp(origEnergy-newEnergy), 1);
    
    if rand(1,1) <= acceptRatio
        r0 = proposed_r;
        original_m_logP = new_m_logP;
        accept_count = accept_count + 1;
    else
        F0 = F_start;
        r0 = r_start;
    end
    qHistory_expHMC(:, n) = r0;
end

qHistory_expHMC = inv_sqrt_M*qHistory_expHMC + mu*ones(1, num_sample);
TIME_spent = toc;
display(['acceptance rate = ' num2str(accept_count/num_sample)]);
acc_rate = accept_count/num_sample;
end