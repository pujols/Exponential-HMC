function structure = precompute_fastBLR(mu, sigmaInverse, h, inv_sqrt_M)

%% First, perform translation
structure.mu = mu;
structure.h = h;
% =================== speed up ====================================
% nonlinearPart = @(q) (m_gradLogP(q) - sigmaInverse*(q-mu));
% N = @(q) nonlinearPart(q+mu); % center about mean
% % N = @(q) (m_gradLogP(q+mu) - sigmaInverse*(q));
% 
% %% Second, perform transformation
% if (sum(sum(abs(inv_sqrt_M - eye(size(inv_sqrt_M))))) < 10^-6)
%     squared_omega = sigmaInverse;
%     F = @(r) N(r);
% %     F = @(r) (m_gradLogP(r+mu) - sigmaInverse*(r)); 
% else
%     squared_omega = inv_sqrt_M*sigmaInverse*inv_sqrt_M;
%     F = @(r) inv_sqrt_M*N(inv_sqrt_M*r);
% %     F = @(r) inv_sqrt_M*(m_gradLogP(inv_sqrt_M*r+mu) - sigmaInverse*(inv_sqrt_M*r));
% end
% structure.F = F;
% =================================================================
squared_omega = inv_sqrt_M*sigmaInverse*inv_sqrt_M;
% squared_omega = eye(size(sigmaInverse));
[V,D] = eig(squared_omega);
% V = V*diag(1./sqrt(sum(V.^2, 1))); % just a double check
% squared_omega = V*D*V'
squaredVals = diag(D);
notSquared = sqrt(squaredVals);

structure.cosine = V * diag(cos(h*notSquared)) * V';
structure.sine = V * diag(sin(h*notSquared)) * V';
structure.omega = V * diag(notSquared) * V';
% structure.omegaInverse = V * diag(1./notSquared) * V';
structure.omegaInverse = V * diag(new_divid(1, notSquared)) * V';

% sincVals = sin(h*notSquared)./(h*notSquared);
sincVals = sinc_divid(sin(h*notSquared), (h*notSquared));
structure.sinc = V * diag(sincVals) * V';
structure.sincSquared = V * diag(sincVals.^2) * V';
structure.CosineTimeSinc = V * diag(cos(h*notSquared).*sincVals) * V';

structure.fast1 = structure.omegaInverse*structure.sine;
structure.fast2 = 0.5*structure.h^2*structure.sincSquared;
structure.fast3 = structure.omega*structure.sine;
structure.fast4 = 0.5*structure.h*structure.CosineTimeSinc;
structure.fast5 = 0.5*structure.h*structure.sinc;
end

function C = new_divid(A, B)
    C = A./B;
    C(B == 0) = 0;
end

function C = sinc_divid(A, B)
    C = A./B;
    C(B == 0) = 1;
end