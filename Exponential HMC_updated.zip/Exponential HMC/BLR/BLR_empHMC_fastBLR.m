function [ ] = BLR_empHMC_fastBLR( DataSet, scaleHCM, NumOfLeapFrogSteps1, sigma, NumOfIterations1, BurnIn1, scale_StepSize, num_initial, num_update )

%% Input:
% DataSet: dataset name (e.g., 'Australian')
% scaleHCM: changing the ratio of h and L. When scaleHCM = 2, it runs for
% 2h and L/2 (in the paper, we try 1, 2, 4)
% NumOfLeapFrogSteps1: L (default 1000)
% sigma: parameters of prior (in the paper, we try 0.01, 1, 100)
% NumOfIterations1: totoal iterations (bur-in + real samples) to run (default 10000)
% BurnIn1: # burn-in samples (default 5000)
% scale_StepSize: scaling up the default stepsize (default 1 for sigma = 1, 100; 1/2 for sigma = 0.01)
% num_initial, num_update: initial and updating interval (N1, N2 in the paper; default: N1 = 500; N2 = 250)

% addpath('C:\Users\User\Desktop\HMC\Codes\Server');
% addpath('C:\Users\User\Desktop\HMC\Codes');
% Random Numbers...
randn('state', sum(100*clock));
rand('twister', sum(100*clock));

switch(DataSet)

    case 'Australian'
    
        %Two hyperparameters of model
        Polynomial_Order = 1;
        alpha=100; 

        %Load and prepare train & test data
        load('./Data/australian.mat');
        t=X(:,end);
        X(:,end)=[];
        
        % Normalise Data
        [N, D] = size(X);
        X = (X-repmat(mean(X),N,1))./repmat(std(X),N,1);

        %Create Polynomial Basis
        XX = ones(size(X,1),1);
        for i = 1:Polynomial_Order
            XX = [XX X.^i];
        end
        [N,D] = size(XX);

        % HMC Setup
        NumOfIterations    = 6000;
        BurnIn             = 1000;
        NumOfLeapFrogSteps = 100;
        
        StepSize           = 0.1;
        Mass               = diag(ones(D,1)*1);

        
    case 'German'

        %Two hyperparameters of model
        Polynomial_Order = 1;
        alpha=100; 

        %Load and prepare train & test data
        load('./Data/german.mat');
        t=X(:,end);
        X(:,end)=[];

        % Normalise Data
        [N, D] = size(X);
        X = (X-repmat(mean(X),N,1))./repmat(std(X),N,1);
        
        % German Credit - replace all 1s in t with 0s
        t(find(t==1)) = 0;
        % German Credit - replace all 2s in t with 1s
        t(find(t==2)) = 1;

        %Create Polynomial Basis
        XX = ones(size(X,1),1);
        for i = 1:Polynomial_Order
            XX = [XX X.^i];
        end

        [N,D] = size(XX);
        
        % HMC Setup
        NumOfIterations    = 6000;
        BurnIn             = 1000;
        NumOfLeapFrogSteps = 100;
        StepSize           = 0.05;
        Mass               = diag(ones(D,1)*1);
        
        
    case 'Heart'
        
        %Two hyperparameters of model
        Polynomial_Order = 1;
        alpha=100; 

        %Load and prepare train & test data
        load('./Data/heart.mat');
        t=X(:,end);
        X(:,end)=[];

        % Normalise Data
        [N, D] = size(X);
        X = (X-repmat(mean(X),N,1))./repmat(std(X),N,1);
        
        % German Credit - replace all 1s in t with 0s
        t(find(t==1)) = 0;
        % German Credit - replace all 2s in t with 1s
        t(find(t==2)) = 1;

        %Create Polynomial Basis
        XX = ones(size(X,1),1);
        for i = 1:Polynomial_Order
            XX = [XX X.^i];
        end

        [N,D] = size(XX);

        % HMC Setup
        NumOfIterations    = 6000;
        BurnIn             = 1000;
        NumOfLeapFrogSteps = 100;
        StepSize           = 0.14;
        Mass               = diag(ones(D,1)*1);
        
    case 'Pima'

        %Two hyperparameters of model
        Polynomial_Order = 1;
        alpha=100; 

        %Load and prepare train & test data
        load('./Data/pima.mat');
        t=X(:,end);
        X(:,end)=[];

        % Normalise Data
        [N, D] = size(X);
        X = (X-repmat(mean(X),N,1))./repmat(std(X),N,1);
        
        %Create Polynomial Basis
        XX = ones(size(X,1),1);
        for i = 1:Polynomial_Order
            XX = [XX X.^i];
        end

        [N,D] = size(XX);

        % HMC Setup
        NumOfIterations    = 6000;
        BurnIn             = 1000;
        NumOfLeapFrogSteps = 100;
        StepSize           = 0.1;
        Mass               = diag(ones(D,1)*1);
        
    case 'Ripley'

        %Two hyperparameters of model
        Polynomial_Order = 3;
        alpha=100;

        %Load and prepare train & test data
        load('./Data/ripley.mat');
        t=X(:,end);
        X(:,end)=[];

        % Normalise Data
        [N, D] = size(X);
        X = (X-repmat(mean(X),N,1))./repmat(std(X),N,1);
        
        %Create Polynomial Basis
        XX = ones(size(X,1),1);
        for i = 1:Polynomial_Order
            XX = [XX X.^i];
        end

        [N,D] = size(XX);

        % HMC Setup
        NumOfIterations    = 6000;
        BurnIn             = 1000;
        NumOfLeapFrogSteps = 100;
        StepSize           = 0.14;
        Mass               = diag(ones(D,1)*1);
end

alpha = sigma;
NumOfLeapFrogSteps = NumOfLeapFrogSteps1;
NumOfIterations = NumOfIterations1;
BurnIn = BurnIn1;
StepSize = scale_StepSize*StepSize;

% scaleHCM = 1;
[~, ~, m_logP, m_gradLogP, ~] = Laplace_BLR(XX, t, alpha);
[qHistory_expHMC, TimeTaken, acc_rate] = empHMC_fastBLR(m_gradLogP, m_logP, Mass, StepSize, NumOfLeapFrogSteps, BurnIn, (NumOfIterations-BurnIn), zeros(D, 1), num_initial, num_update, scaleHCM, XX, t, alpha);
betaPosterior = qHistory_expHMC';
TimeTaken
CurTime = fix(clock);
% cd('..')
filename = ['Results/empHMC_' num2str(sigma) '_'  num2str(NumOfLeapFrogSteps) '_' num2str(scale_StepSize) '_' num2str(scaleHCM) '_' DataSet '_' num2str(randi([1, 100])) '_' num2str(CurTime(4)) num2str(CurTime(5)) num2str(CurTime(6)) '.mat'];
save(filename, 'betaPosterior', 'TimeTaken', 'acc_rate')

end

