function [qHistory_expHMC, TIME_spent, acc_rate] = empHMC_fastBLR_simple(m_gradLogP, m_logP, M, h, L, num_burn, num_sample, q_initial, initial_interval, updating_interval, scaleHCM, X, Y, sigma_prior)
% function [qHistory_expHMC, TIME_spent, acc_rate] = emp_expHMC_fastBLR_full_simple(m_gradLogP, m_logP, M, h, L, num_burn, num_sample, q_initial, initial_interval, updating_interval, scaleHCM, X, Y, sigma_prior)
% rng('shuffle');
%% Parameters 
% HMC parameters: m(inus)_gradLogP, m(inus)_logP, M, h(step size), L(#steps) 
% MCMC parameters: num_burn, num_sample
% empirical parameters: initial_ratio, updating_interval

%% Presetting
sqrt_M = M^(0.5);
inv_sqrt_M = inv(sqrt_M);
inv_M = inv(M);
[N, D] = size(X);
small_offset = (10^-10)*eye(D);
%% Initialization
d = length(q_initial);
if (q_initial(1) == 10^10)
    q = randn(d, 1);
else
    q = q_initial;
end

%% Burning + initial_interval (by leapfrog HMC)
qHistory_leapfrogHMC_burn = zeros(d, num_burn);

for n = 1: num_burn
% Random p
    z = randn(d, 1);
    p = sqrt_M*z;
    p0 = p;
    q0 = q;
    origEnergy = m_logP(q) + 0.5*(p'*(M\p));
    
% Run L times
    RandomStep = ceil(rand*(L-1))+1;
    GG_flag = 0;
    p0 = p0 - 0.5*h*m_gradLogP(q0);
    for m = 1:(RandomStep-1)
        if(isnan(sum(p0)) || isnan(sum(q0)) || isinf(sum(p0)) || isinf(sum(q0)))
            GG_flag = 1;
            break;
        end
        q0 = q0 + h*(M\p0);
        p0 = p0 - h*m_gradLogP(q0);
        q0 = real(q0);
        p0 = real(p0);
    end
    if (GG_flag == 0)
        q0 = q0 + h*(M\p0);
        p0 = p0 - 0.5*h*m_gradLogP(q0);
    else
        p0 = p0 + 0.5*h*m_gradLogP(q0);
    end
    
    % Acceptance-rejection
    proposedP = p0;
    proposedQ = q0;
    
    newEnergy = m_logP(proposedQ) + 0.5*(proposedP'*(M\proposedP));
    acceptRatio = min(exp(origEnergy-newEnergy), 1);
    
    if rand(1,1) <= acceptRatio
        q = proposedQ;
    end
    qHistory_leapfrogHMC_burn(:, n) = q;
end





%% Sampling (by emp_expHMC)
accept_count = 0;
qHistory_expHMC = zeros(d, num_sample);

%% Into expHMC step size 
h = h*scaleHCM;
L = round(L/scaleHCM);
emp_samples = qHistory_leapfrogHMC_burn(:, num_burn-initial_interval+1:end);

% transformation
% =============== Speed Up 1 ====================================
XY = X'*Y;
sqrt_MXY = inv_sqrt_M*XY;
sqrt_MX = inv_sqrt_M*(X');
% ===============================================================

tic;
mu = mean(emp_samples, 2);
sigma = (emp_samples - mu*ones(1, initial_interval)) * (emp_samples - mu*ones(1, initial_interval))' / initial_interval;
sigmaInverse = inv(sigma+small_offset);
structure = precompute_fastBLR_simple(mu, sigmaInverse, h, inv_sqrt_M);

% =============== Speed Up 2 ====================================
Xmu = X*mu;
sqrt_Mmu = inv_sqrt_M*mu;
sqrt_MsigmaInversesqrt_M = inv_sqrt_M*sigmaInverse*inv_sqrt_M;
sqrt_Mmusigma_prior = sqrt_Mmu/sigma_prior;
fastALL = sqrt_Mmusigma_prior - sqrt_MXY;
% ===============================================================

% Precomputing
% =============== Speed Up ======================================
SUP1 = inv_M/sigma_prior;
SUP2 = X*inv_sqrt_M;
SUP3 = sqrt_MsigmaInversesqrt_M;
SUP4 = SUP1 - SUP3;
% ===============================================================

updating_count = 0;
original_m_logP = m_logP(q);
qt = q - mu;
r0 = sqrt_M*qt;
% sr0 = structure.sinc*r0;
F0 = fastALL + sqrt_MX*(1./(1+exp(-(SUP2*r0)-Xmu))) + SUP4*r0;

for n = 1: num_sample
    
    updating_count = updating_count + 1;
% Random p
    z0 = randn(d, 1);
    origEnergy = original_m_logP + 0.5*(z0'*z0);
    
% Run L times
    F_start = F0;
    r_start = r0;
    RandomStep = ceil(rand*L);
    for m = 1:RandomStep
% =============== Speed Up ======================================
%         [z11, r11, F11] = exponentialStep_fastBLR(z0, r0, structure, F0, X, M, sqrt_M, sigma_prior, Xmu, sqrt_MsigmaInversesqrt_M, sqrt_MX, fastALL);
        r11 = structure.cosine*r0 + structure.fast1*z0 - structure.fast2*F0;
        % sr = structure.sinc*r11;
        F11 = fastALL + sqrt_MX*(1./(1+exp(-(SUP2*r11)-Xmu))) + SUP4*r11;
        z11 = -structure.fast3*r0 + structure.cosine*z0 - (structure.fast4*F0 + structure.fast5*F11); 
% ===============================================================
        if(isnan(sum(r11)) || isnan(sum(z11)) || isinf(sum(r11)) || isinf(sum(z11)))
            break;
        end
        z0 = real(z11); r0 = real(r11); F0 = real(F11);
    end
    
% Acceptance-rejection
    proposed_z = z0;
    proposed_r = r0;

% =============== Speed Up ======================================
    proposedQ = inv_sqrt_M*proposed_r + mu;
    new_m_logP = 0.5*(proposedQ'*proposedQ)/sigma_prior - (proposedQ'*XY - sum(log(1+exp(X*proposedQ))));
% ===============================================================
    newEnergy = new_m_logP + 0.5*(proposed_z'*proposed_z);
    acceptRatio = min(exp(origEnergy-newEnergy), 1);
    
    if rand(1,1) <= acceptRatio
        r0 = proposed_r;
        original_m_logP = new_m_logP;
        accept_count = accept_count + 1;
    else
        F0 = F_start;
        r0 = r_start;
    end
    qHistory_expHMC(:, n) = inv_sqrt_M*r0 + mu;
    
    if (updating_count >= updating_interval)
        q = qHistory_expHMC(:, n);
        mu = mean([emp_samples, qHistory_expHMC(:, 1:n)], 2);
        sigma = ([emp_samples, qHistory_expHMC(:, 1:n)] - mu*ones(1, initial_interval+n)) * ([emp_samples, qHistory_expHMC(:, 1:n)] - mu*ones(1, initial_interval+n))' / (initial_interval+n);
        sigmaInverse = inv(sigma+small_offset);
        structure = precompute_fastBLR_simple(mu, sigmaInverse, h, inv_sqrt_M);
        
% =============== Speed Up 2 ====================================
        Xmu = X*mu;
        sqrt_Mmu = inv_sqrt_M*mu;
        sqrt_MsigmaInversesqrt_M = inv_sqrt_M*sigmaInverse*inv_sqrt_M;
        sqrt_Mmusigma_prior = sqrt_Mmu/sigma_prior;
        fastALL = sqrt_Mmusigma_prior - sqrt_MXY;
% ===============================================================

% Precomputing
% =============== Speed Up ======================================
        SUP1 = inv_M/sigma_prior;
        SUP2 = X*inv_sqrt_M;
        SUP3 = sqrt_MsigmaInversesqrt_M;
        SUP4 = SUP1 - SUP3;
% ===============================================================

        updating_count = 0;
        qt = q - mu;
        r0 = sqrt_M*qt;
%         sr0 = structure.sinc*r0;
        F0 = fastALL + sqrt_MX*(1./(1+exp(-(SUP2*r0)-Xmu))) + SUP4*r0;
    end
end

TIME_spent = toc;
display(['acceptance rate = ' num2str(accept_count/num_sample)]);
acc_rate = accept_count/num_sample;
end