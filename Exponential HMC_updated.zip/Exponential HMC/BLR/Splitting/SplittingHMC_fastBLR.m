function [qHistory_expHMC, TIME_spent, acc_rate] = SplittingHMC_fastBLR(mu, sigmaInverse, m_gradLogP, m_logP, M, h, L, num_burn, num_sample, q_initial, X, Y, sigma_prior)
% function [qHistory_expHMC, TIME_spent, acc_rate] = SplittingHMC_fastBLR_full(mu, sigmaInverse, m_gradLogP, m_logP, M, h, L, num_burn, num_sample, q_initial, X, Y, sigma_prior)
% rng('shuffle');
%% Parameters
% Exponential parameters: mu, sigmaInverse 
% HMC parameters: m(inus)_gradLogP, m(inus)_logP, M, h(step size), L(#steps) 
% MCMC parameters: num_burn, num_sample

%% Presetting
sqrt_M = M^(0.5);
% inv_sqrt_M = inv(sqrt_M);
inv_M = inv(M);
sqrt_sigmaInverse = sigmaInverse^(0.5);

% [N, D] = size(X);
%% Initialization
d = length(mu);
if (q_initial(1) == 10^10)
    q = randn(d, 1); q = sqrt_sigmaInverse\q + mu;
else
    q = q_initial;
end

% Precomputing
% =============== Speed Up ======================================
XY = X'*Y;
Pre_ALL =  0.5*h*(-XY + sigmaInverse*mu);
SUP1 = 0.5*h*(eye(d)/sigma_prior - sigmaInverse);
SUP2 = 0.5*h*X';

Pre_ALL2 =  2*Pre_ALL;
SUP12 = 2*SUP1;
SUP22 = 2*SUP2;
% ===============================================================

% transformation
structure = precomputeSplitting_new(mu, sigmaInverse, m_gradLogP, h, inv_M);
original_m_logP = m_logP(q);

%% Burning
qHistory_expHMC_burn = zeros(d, num_burn);

for n = 1:num_burn
% Random p
    z = randn(d, 1);
    p = sqrt_M*z;
    p0 = p;
    q0 = q;
    origEnergy = original_m_logP + 0.5*(p'*inv_M*p);
    
% Run L times
    RandomStep = ceil(rand*(L-1))+1;
    GG_index = 0;
%     p0 = p0 - 0.5*h*(structure.U1(q0));
    p0 = p0 - Pre_ALL - SUP1*q0 - SUP2*(1./(1+exp(-X*q0)));    

    for m = 1:(RandomStep-1)
%         [p0, q0] = SplittingStep_new(p0, q0, structure);
        q0 = q0 - structure.mu;
        X1 = structure.R*[q0; p0];
        q0 = X1(1 : d, 1) + structure.mu;
        p0 = X1(d+1 : 2*d, 1);
        if(isnan(sum(p0)) || isnan(sum(q0)) || isinf(sum(p0)) || isinf(sum(q0)))
            GG_index = 1;
            break;
        end
%         p0 = p0 - h*(structure.U1(q0));
        p0 = p0 - Pre_ALL2 - SUP12*q0 - SUP22*(1./(1+exp(-X*q0)));     
    end
    
    if (GG_index == 1)
%         p0 = p0 + 0.5*h*(structure.U1(q0));
        p0 = p0 + Pre_ALL + SUP1*q0 + SUP2*(1./(1+exp(-X*q0)));      
    else
%     [p0, q0] = SplittingStep_new(p0, q0, structure);
%     p0 = p0 - 0.5*h*(structure.U1(q0));
        q0 = q0 - structure.mu;
        X1 = structure.R*[q0; p0];
        q0 = X1(1 : d, 1) + structure.mu;
        p0 = X1(d+1 : 2*d, 1);
        p0 = p0 - Pre_ALL - SUP1*q0 - SUP2*(1./(1+exp(-X*q0)));       
    end
    
    % Acceptance-rejection
    proposedP = p0;
    proposedQ = q0;

% =============== Speed Up ======================================
    new_m_logP = 0.5*(proposedQ'*proposedQ)/sigma_prior - (proposedQ'*XY - sum(log(1+exp(X*proposedQ))));
% ===============================================================
    newEnergy = new_m_logP + 0.5*(proposedP'*inv_M*proposedP);
    acceptRatio = min(exp(origEnergy-newEnergy), 1);
    
    if rand(1,1) <= acceptRatio
        q = proposedQ;
        original_m_logP = new_m_logP;
    end
    qHistory_expHMC_burn(:, n) = q;
end

%% Sampling
% m_gradLogP = @(q) q/sigma_prior + X'*(1./(1+exp(-X*q)) - Y);
% m_logP = @(q) 0.5*q'*q/sigma_prior - (q'*X'*Y - sum(log(1+exp(X*q))));
% nonlinearPart = @(q) m_gradLogP(q) - InverseSigma_posterior*(q-Mu);

accept_count = 0;
qHistory_expHMC = zeros(d, num_sample);
% =============== Speed Up 1=====================================
XY = X'*Y;
SUP2 = 0.5*h*X';
SUP22 = 2*SUP2;
% ===============================================================
tic;
% Precomputing
% =============== Speed Up 2=====================================
Pre_ALL =  0.5*h*(-XY + sigmaInverse*mu);
SUP1 = 0.5*h*(eye(d)/sigma_prior - sigmaInverse);
Pre_ALL2 =  2*Pre_ALL;
SUP12 = 2*SUP1;
% ===============================================================

% transformation
structure = precomputeSplitting_new(mu, sigmaInverse, m_gradLogP, h, inv_M);
original_m_logP = m_logP(q);

for n = 1:num_sample
% Random p
    z = randn(d, 1);
    p = sqrt_M*z;
    p0 = p;
    q0 = q;
    origEnergy = original_m_logP + 0.5*(p'*inv_M*p);
    
% Run L times
    RandomStep = ceil(rand*(L-1))+1;
    GG_index = 0;
%     p0 = p0 - 0.5*h*(structure.U1(q0));
    p0 = p0 - Pre_ALL - SUP1*q0 - SUP2*(1./(1+exp(-X*q0)));    

    for m = 1:(RandomStep-1)
%         [p0, q0] = SplittingStep_new(p0, q0, structure);
        q0 = q0 - structure.mu;
        X1 = structure.R*[q0; p0];
        q0 = X1(1 : d, 1) + structure.mu;
        p0 = X1(d+1 : 2*d, 1);
        if(isnan(sum(p0)) || isnan(sum(q0)) || isinf(sum(p0)) || isinf(sum(q0)))
            GG_index = 1;
            break;
        end
%         p0 = p0 - h*(structure.U1(q0));
        p0 = p0 - Pre_ALL2 - SUP12*q0 - SUP22*(1./(1+exp(-X*q0)));   
    end
    
    if (GG_index == 1)
%         p0 = p0 + 0.5*h*(structure.U1(q0));
        p0 = p0 + Pre_ALL + SUP1*q0 + SUP2*(1./(1+exp(-X*q0)));     
    else
%     [p0, q0] = SplittingStep_new(p0, q0, structure);
%     p0 = p0 - 0.5*h*(structure.U1(q0));
        q0 = q0 - structure.mu;
        X1 = structure.R*[q0; p0];
        q0 = X1(1 : d, 1) + structure.mu;
        p0 = X1(d+1 : 2*d, 1);
        p0 = p0 - Pre_ALL - SUP1*q0 - SUP2*(1./(1+exp(-X*q0)));   
    end
    
    % Acceptance-rejection
    proposedP = p0;
    proposedQ = q0;

% =============== Speed Up ======================================
    new_m_logP = 0.5*(proposedQ'*proposedQ)/sigma_prior - (proposedQ'*XY - sum(log(1+exp(X*proposedQ))));
% ===============================================================
    newEnergy = new_m_logP + 0.5*(proposedP'*inv_M*proposedP);
    acceptRatio = min(exp(origEnergy-newEnergy), 1);
    
    if rand(1,1) <= acceptRatio
%         display('accepted');
        q = proposedQ;
        original_m_logP = new_m_logP;
        accept_count = accept_count + 1;
    else
%         display('rejected');
    end
    qHistory_expHMC(:, n) = q;
end

TIME_spent = toc;
display(['acceptance rate = ' num2str(accept_count/num_sample)]);
acc_rate = accept_count/num_sample;
end