These codes are for the Gaussian splitting method

Please put them into the folder "Exponential HMC\BLR"