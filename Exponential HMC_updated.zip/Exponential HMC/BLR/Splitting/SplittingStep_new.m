function [p1, q1] = SplittingStep_new(p0, q0, structure)
    d = size(q0, 1); 
    q0 = q0 - structure.mu;
    X1 = structure.R*[q0; p0];
    q1 = X1(1 : d, 1) + structure.mu;
    p1 = X1(d+1 : 2*d, 1);
end

    
