function structure = precomputeSplitting_new(mu, sigmaInverse, m_gradLogP, h, inv_M)

%% First, perform translation
structure.mu = mu;
structure.h = h;
structure.U1 = @(q) (m_gradLogP(q) - sigmaInverse*(q-mu));
A = [zeros(size(sigmaInverse)), inv_M; -sigmaInverse, zeros(size(sigmaInverse))];
[V, D] = eig(A);
structure.R = real(V*diag(exp(h*diag(D)))/V);
% structure.R = expm(h*A);