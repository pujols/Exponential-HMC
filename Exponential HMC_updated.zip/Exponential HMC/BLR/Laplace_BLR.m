function [Mu, InverseSigma_posterior, m_logP, m_gradLogP, nonlinearPart] = Laplace_BLR(X, Y, sigma_prior)
%% This is the script to perform Laplace approximation of the Bayesian logistic regression

% Input:
% X: N*D matrix
% Y: N*1 matrix: (0, 1) case
% sigma: the variance of the prior of w

%% Preprocessing
[~, D] = size(X);

%% MAP computation of L2_regularized logistic regression
addpath('./liblinear-1.96/matlab');
display('Now training L2_regularized logistic regression');
tic;
model_logistic = train(Y, sparse(X), ['-s 0 -c ' num2str(sigma_prior) ' -e 0.001 -q']);
toc;

%% Post_processing (w_MAP)
w_MAP = (model_logistic.w)';
if (model_logistic.Label(1) < model_logistic.Label(2))
    w_MAP = -w_MAP;
end

%% Output
Mu = w_MAP;
f = 1./(1+exp(-X*Mu));
S = diag(f.*(1-f));
InverseSigma_posterior = 1/sigma_prior*eye(D) + X'*S*X;
m_gradLogP = @(q) q/sigma_prior + X'*(1./(1+exp(-X*q)) - Y);
m_logP = @(q) 0.5*(q'*q)/sigma_prior - (q'*X'*Y - sum(log(1+exp(X*q))));
nonlinearPart = @(q) m_gradLogP(q) - InverseSigma_posterior*(q-Mu);
end