%% The following codes starting with "MNIST" are those to load dataset, run sampling, and save samples.

% leapfrog HMC
MNIST_hmc.m

% expHMC, empHMC (empirical statistics), R_expHMC (rmExpHMC: manifold structure) with "mollified" filters
MNIST_expHMC_fastBLR.m
MNIST_empHMC_fastBLR.m
MNIST_R_empHMC_fastBLR.m

% expHMC, empHMC (empirical statistics), R_expHMC (rmExpHMC: manifold structure) with "simple" filters
MNIST_expHMC_fastBLR_simple.m
MNIST_empHMC_fastBLR_simple.m
MNIST_R_expHMC_fastBLR_simple.m

###########################################################################################################

%% The following codes are those called by the above ones to execute sampling

% expHMC, empHMC (empirical statistics), R_expHMC (rmExpHMC: manifold structure) with "mollified" filters
expHMC_fastBLR.m
empHMC_fastBLR.m
R_expHMC_fastBLR.m

% expHMC, empHMC (empirical statistics), R_expHMC (rmExpHMC: manifold structure) with "simple" filters
expHMC_fastBLR_simple.m
empHMC_fastBLR_simple.m
R_expHMC_fastBLR_simple.m