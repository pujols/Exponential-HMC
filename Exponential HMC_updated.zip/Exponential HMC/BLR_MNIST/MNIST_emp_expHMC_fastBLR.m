function [] = MNIST_emp_expHMC_fastBLR(scaleHCM, NumOfLeapFrogSteps1, sigma, NumOfIterations1, BurnIn1, scale_StepSize, num_initial, num_update, StepSize)

%% Input:
% scaleHCM: changing the ratio of h and L. When scaleHCM = 2, it runs for
% 2h and L/2.
% NumOfLeapFrogSteps1: L (default 30)
% sigma: parameters of prior (default 0.01)
% NumOfIterations1: totoal iterations (bur-in + real samples) to run (default = 40000)
% BurnIn1: # burn-in samples (default = 10000)
% scale_StepSize: scaling up the default stepsize (default 1)
% num_initial, num_update: initial annd updating intrval (N1, N2 in the paper; default N1 = 2000, N2 =2000)
% StepSize: check the paper for the default stepsize (default = 0.013)

% Random Numbers...
randn('state', sum(100*clock));
rand('twister', sum(100*clock));

%% Pre data processing
%Two hyperparameters of model
Polynomial_Order = 1;

%Load and prepare train & test data
load('./Data/MNIST_79.mat');
t = Y_train;
t(t~=1) = 0;
X = full(X_train);
N = size(X,1);

% Standardise Data
X = (X-repmat(mean(X),N,1))./repmat(std(X),N,1);

%Create Polynomial Basis
XX = ones(size(X,1),1);
for i = 1:Polynomial_Order
    XX = [XX X.^i];
end
[N,D] = size(XX)

% HMC Setup
Mass = diag(ones(D,1)*1);
alpha = sigma;
NumOfLeapFrogSteps = NumOfLeapFrogSteps1;
NumOfIterations = NumOfIterations1;
BurnIn = BurnIn1;
StepSize = scale_StepSize*StepSize;

%% Starting job working
[mu, sigmaInverse, m_logP, m_gradLogP, ~] = Laplace_BLR(XX, t, alpha);
[qHistory_expHMC, TimeTaken, acc_rate] = emp_expHMC_fastBLR_full(m_gradLogP, m_logP, Mass, StepSize, NumOfLeapFrogSteps, BurnIn, (NumOfIterations-BurnIn), zeros(D, 1), num_initial, num_update, scaleHCM, XX, t, alpha);

betaPosterior = qHistory_expHMC';
TimeTaken
CurTime = fix(clock);

% cd('..')
filename = ['MNIST_Results/MNIST_empHMC' num2str(sigma) '_'  num2str(NumOfLeapFrogSteps) '_' num2str(scale_StepSize) '_' num2str(scaleHCM) '_a9a_' num2str(randi([1, 100])) '_' num2str(CurTime(4)) num2str(CurTime(5)) num2str(CurTime(6)) '.mat'];
save(filename, 'betaPosterior', 'TimeTaken', 'acc_rate')

end