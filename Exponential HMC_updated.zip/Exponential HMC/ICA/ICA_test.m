function ICA_test(method_index, stepsize, num_step, num_burn, num_sample, scaleHCM, initial_interval, updating_interval, sigma_prior)

% method_index: 1) leapfrog_HMC 2) empHMC 3) empHMC (simple)
% stepsize: (default 5*10^-5)
% num_step: L (default 50)
% num_burn: # burn-in samples (default 5000)
% num_sample: # real samples (default 5000)
% scaleHCM: changing the ratio of h and L. When scaleHCM = 2, it runs for
% 2h and L/2 (in the paper, we try 1, 2, 4)
% initial_interval, updating_interval: initial and updating interval for empHMC (N1, N2 in the paper; default: N1 = 500; N2 = 250)
% sigma_prior: parameters of prior (default 100)

%% Data preparation
load('./Data/ICA_data.mat');
X = X';
X = X(:, 1:5);
[N, D] = size(X); disp([N, D]);
%% Presetting
q_initial = rand(D*D, 1);
h = stepsize;
L = num_step;
M = eye(D*D);
mu = zeros(D*D, 1);
sigmaInverse = eye(D*D)/sigma_prior;

%% Method
for n = 1:length(method_index)
    %% General methods
    if(method_index(n) == 1)
        [qHistory_expHMC, TIME_spent, acc_rate] = leapfrog_ICA(M, h*scaleHCM, ceil(L/scaleHCM), num_burn, num_sample, q_initial, X, sigma_prior);
        betaPosterior = qHistory_expHMC';
        TimeTaken = TIME_spent
        CurTime = fix(clock);
        filename = ['Results_ICA/ICA_leapfrogHMC_' num2str(sigma_prior) '_'  num2str(stepsize) '_' num2str(num_step) '_' num2str(scaleHCM) '_' num2str(randi([1, 100])) '_' num2str(CurTime(4)) num2str(CurTime(5)) num2str(CurTime(6)) '.mat'];
        save(filename, 'betaPosterior', 'TimeTaken', 'acc_rate');
        
    elseif(method_index(n) == 2)
        [qHistory_expHMC, TIME_spent, acc_rate] = emp_expHMC_fastICA_full(M, h, L, num_burn, num_sample, q_initial, initial_interval, updating_interval, scaleHCM, X, sigma_prior);
        betaPosterior = qHistory_expHMC';
        TimeTaken = TIME_spent
        CurTime = fix(clock);
        filename = ['Results_ICA/ICA_empHMC_' num2str(sigma_prior) '_'  num2str(stepsize) '_' num2str(num_step) '_' num2str(scaleHCM) '_' num2str(initial_interval) '_' num2str(updating_interval) '_' num2str(randi([1, 100])) '_' num2str(CurTime(4)) num2str(CurTime(5)) num2str(CurTime(6)) '.mat'];
        save(filename, 'betaPosterior', 'TimeTaken', 'acc_rate');
        
    elseif(method_index(n) == 3)
        [qHistory_expHMC, TIME_spent, acc_rate] = emp_expHMC_fastICA_full_simple(M, h, L, num_burn, num_sample, q_initial, initial_interval, updating_interval, scaleHCM, X, sigma_prior);
        betaPosterior = qHistory_expHMC';
        TimeTaken = TIME_spent
        CurTime = fix(clock);
        filename = ['Results_ICA/ICA_empsHMC_' num2str(sigma_prior) '_'  num2str(stepsize) '_' num2str(num_step) '_' num2str(scaleHCM) '_' num2str(initial_interval) '_' num2str(updating_interval) '_' num2str(randi([1, 100])) '_' num2str(CurTime(4)) num2str(CurTime(5)) num2str(CurTime(6)) '.mat'];
        save(filename, 'betaPosterior', 'TimeTaken', 'acc_rate');
        
    end
end