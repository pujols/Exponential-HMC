clear all;
close all;
clc;

alpha = 100;
scaleHCM = 1; % 2, 4
%ICA_test(method_index, stepsize, num_step, num_burn, num_sample, scaleHCM, initial_interval, updating_interval, sigma_prior, U_interval);

% method_index: 1) leapfrog_HMC 2) empHMC 3) empHMC (simple)
% stepsize: (default 5*10^-5)
% num_step: L (default 50)
% num_burn: # burn-in samples (default 5000)
% num_sample: # real samples (default 5000)
% scaleHCM: changing the ratio of h and L. When scaleHCM = 2, it runs for
% 2h and L/2 (in the paper, we try 1, 2, 4)
% initial_interval, updating_interval: initial and updating interval for empHMC (N1, N2 in the paper; default: N1 = 500; N2 = 250)
% sigma_prior: parameters of prior (default 100)

ICA_test(2, 5*10^-5, 50, 5000, 5000, scaleHCM, 500, 250, alpha);
