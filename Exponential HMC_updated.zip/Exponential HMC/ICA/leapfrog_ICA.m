function [qHistory_expHMC, TIME_spent, acc_rate] = leapfrog_ICA(M, h, L, num_burn, num_sample, q_initial, X, sigma_prior)

% rng('shuffle');
%% Parameters 
% HMC parameters: m(inus)_gradLogP, m(inus)_logP, M, h(step size), L(#steps) 
% MCMC parameters: num_burn, num_sample
% empirical parameters: initial_ratio, updating_interval

%% Presetting
sqrt_M = M^(0.5);
inv_sqrt_M = inv(sqrt_M);
inv_M = inv(M);
% sqrt_sigmaInverse = sigmaInverse^(0.5);

[N, D] = size(X); small_offset = (10^-10)*eye(D); small_offset2 = (10^-10)*eye(D*D);
%% Initialization
d = length(q_initial);
if (q_initial(1) == 10^10)
    q = randn(d, 1);
else
    q = q_initial;
end
W = vec2mat(q, D);
% W_mu = vec2mat(mu, D);
% transformation:
% W = D-by-D; Y = X*W'; 
% m_logP = -( N*log(abs(det(W))) - sum(sum(log4 + 2*log(cosh(0.5*W*X')))) - sum(W.*W)/2/sigma_prior);
% m_logP = -( N*log(abs(det(W))) - sum(sum(2*log(cosh(0.5*W*X')))) - q'*q/2/sigma_prior);
% m_gradLogP = -(N*eye(D)-tanh(0.5*Y')*Y)*inv(W') + W/sigma_prior;
%% Burning + initial_interval (by leapfrog HMC)
qHistory_leapfrogHMC_burn = zeros(d, num_burn);
N_eye = N*eye(D);
orig_mlogP = -( N*log(abs(det(W))) - sum(sum(2*log(cosh(0.5*W*X')))) - (q'*q)/2/sigma_prior);
for n = 1: num_burn
% Random p
    z = randn(d, 1);
    p = sqrt_M*z;
    p0 = p;
    q0 = q;
    W0 = vec2mat(q0, D);
    origEnergy = orig_mlogP + 0.5*(p'*(M\p));
    
% Run L times
    RandomStep = ceil(rand*L); % RandomStep = ceil(rand*(L-1))+1;
    GG_flag = 0;
    Y = W0*X';
    SUP1 = ((N_eye-tanh(0.5*Y)*Y')*inv(W0'+small_offset) - W0/sigma_prior);
    if (RandomStep >= 1)
        p0 = p0 + 0.5*h*(SUP1(:));
    %     p0 = p0 + 0.5*h*((N*eye(D)-tanh(0.5*Y)*Y')*inv(W0') - W0/sigma_prior);
    end
    for m = 1:(RandomStep-1)
        if(isnan(sum(p0)) || isnan(sum(q0)) || isinf(sum(p0)) || isinf(sum(q0)))
            GG_flag = 1;
            break;
        end
        q0 = q0 + h*(M\p0);
        W0 = vec2mat(q0, D);
        Y = W0*X';
        SUP1 = ((N_eye-tanh(0.5*Y)*Y')*inv(W0'+small_offset) - W0/sigma_prior);
        p0 = p0 + h*(SUP1(:));
%         p0 = p0 + h*((N*eye(D)-tanh(0.5*Y)*Y')*inv(W0') - W0/sigma_prior);
        q0 = real(q0);
        p0 = real(p0);
    end
    if (RandomStep >= 1)
        if (GG_flag == 0)
            q0 = q0 + h*(M\p0);
            W0 = vec2mat(q0, D);
            Y = W0*X';
            SUP1 = ((N_eye-tanh(0.5*Y)*Y')*inv(W0'+small_offset) - W0/sigma_prior);
            p0 = p0 + 0.5*h*(SUP1(:));
    %         p0 = p0 + 0.5*h*((N*eye(D)-tanh(0.5*Y)*Y')*inv(W0') - W0/sigma_prior);
        else
            W0 = vec2mat(q0, D);
            Y = W0*X';
            SUP1 = ((N_eye-tanh(0.5*Y)*Y')*inv(W0'+small_offset) - W0/sigma_prior);
            p0 = p0 - 0.5*h*(SUP1(:));
    %         p0 = p0 - 0.5*h*((N*eye(D)-tanh(0.5*Y)*Y')*inv(W0') - W0/sigma_prior);
        end
    end
    
    % Acceptance-rejection
    if (isnan(sum(p0)) || isinf(sum(p0)))
        z_temp = randn(d, 1);
        p_temp = sqrt_M*z_temp;
        proposedP = p_temp;
    else
        proposedP = p0;
    end
    if (isnan(sum(q0)) || isinf(sum(q0)))
        proposedQ = randn(d, 1);
    else
        proposedQ = q0;
    end
    proposedW = vec2mat(proposedQ, D);
    new_mlogP = -( N*log(abs(det(proposedW))) - sum(sum(2*log(cosh(0.5*proposedW*X')))) - (proposedQ'*proposedQ)/2/sigma_prior);
    newEnergy = new_mlogP + 0.5*(proposedP'*(M\proposedP));
    acceptRatio = min(exp(origEnergy-newEnergy), 1);
    
    if rand(1,1) <= acceptRatio
        q = proposedQ;
        W = vec2mat(q, D);
        orig_mlogP = new_mlogP;
    end
    qHistory_leapfrogHMC_burn(:, n) = q;
end

%% Sampling (by emp_expHMC)
accept_count = 0;
qHistory_expHMC = zeros(d, num_sample);
N_eye = N*eye(D);
tic;
orig_mlogP = -( N*log(abs(det(W))) - sum(sum(2*log(cosh(0.5*W*X')))) - (q'*q)/2/sigma_prior);
for n = 1: num_sample
% Random p
    z = randn(d, 1);
    p = sqrt_M*z;
    p0 = p;
    q0 = q;
    W0 = vec2mat(q0, D);
    origEnergy = orig_mlogP + 0.5*(p'*(M\p));
    
% Run L times
    RandomStep = ceil(rand*L); % RandomStep = ceil(rand*(L-1))+1;
    GG_flag = 0;
    Y = W0*X';
    SUP1 = ((N_eye-tanh(0.5*Y)*Y')*inv(W0'+small_offset) - W0/sigma_prior);
    if (RandomStep >= 1)
        p0 = p0 + 0.5*h*(SUP1(:));
    %     p0 = p0 + 0.5*h*((N*eye(D)-tanh(0.5*Y)*Y')*inv(W0') - W0/sigma_prior);
    end
    for m = 1:(RandomStep-1)
        if(isnan(sum(p0)) || isnan(sum(q0)) || isinf(sum(p0)) || isinf(sum(q0)))
            GG_flag = 1;
            break;
        end
        q0 = q0 + h*(M\p0);
        W0 = vec2mat(q0, D);
        Y = W0*X';
        SUP1 = ((N_eye-tanh(0.5*Y)*Y')*inv(W0'+small_offset) - W0/sigma_prior);
        p0 = p0 + h*(SUP1(:));
%         p0 = p0 + h*((N*eye(D)-tanh(0.5*Y)*Y')*inv(W0') - W0/sigma_prior);
        q0 = real(q0);
        p0 = real(p0);
    end
    if (RandomStep >= 1)
        if (GG_flag == 0)
            q0 = q0 + h*(M\p0);
            W0 = vec2mat(q0, D);
            Y = W0*X';
            SUP1 = ((N_eye-tanh(0.5*Y)*Y')*inv(W0'+small_offset) - W0/sigma_prior);
            p0 = p0 + 0.5*h*(SUP1(:));
    %         p0 = p0 + 0.5*h*((N*eye(D)-tanh(0.5*Y)*Y')*inv(W0') - W0/sigma_prior);
        else
            W0 = vec2mat(q0, D);
            Y = W0*X';
            SUP1 = ((N_eye-tanh(0.5*Y)*Y')*inv(W0'+small_offset) - W0/sigma_prior);
            p0 = p0 - 0.5*h*(SUP1(:));
    %         p0 = p0 - 0.5*h*((N*eye(D)-tanh(0.5*Y)*Y')*inv(W0') - W0/sigma_prior);
        end
    end
    
    % Acceptance-rejection
    if (isnan(sum(p0)) || isinf(sum(p0)))
        z_temp = randn(d, 1);
        p_temp = sqrt_M*z_temp;
        proposedP = p_temp;
    else
        proposedP = p0;
    end
    if (isnan(sum(q0)) || isinf(sum(q0)))
        proposedQ = randn(d, 1);
    else
        proposedQ = q0;
    end
    proposedW = vec2mat(proposedQ, D);
    new_mlogP = -( N*log(abs(det(proposedW))) - sum(sum(2*log(cosh(0.5*proposedW*X')))) - (proposedQ'*proposedQ)/2/sigma_prior);
    newEnergy = new_mlogP + 0.5*(proposedP'*(M\proposedP));
    acceptRatio = min(exp(origEnergy-newEnergy), 1);
    
    if rand(1,1) <= acceptRatio
        q = proposedQ;
        W = vec2mat(q, D);
        orig_mlogP = new_mlogP;
        accept_count = accept_count + 1;
    end
    qHistory_expHMC(:, n) = q;
end

TIME_spent = toc;
display(['acceptance rate = ' num2str(accept_count/num_sample)]);
acc_rate = accept_count/num_sample;
end


function mat_W = vec2mat(vec_q, dim)
   mat_W = reshape(vec_q, dim, []);
end

function vec_q = mat2vec(mat_W)
   vec_q = mat_W(:);
end