Check ICA_exp and ICA_test for details.

